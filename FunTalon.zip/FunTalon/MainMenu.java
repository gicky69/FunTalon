import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;

public class    MainMenu {
    JPanel MainMenu;
    JPanel HTTPanel;
    JLabel MainMenuBG;
    JLabel MainMenuTitle;
    JLabel MainMeneIndc;
    JButton Play;
    Image BgIndcImg = new ImageIcon("Images/MainMenu/indbg.gif").getImage().getScaledInstance(68,54,Image.SCALE_DEFAULT);
    Image PlayButtonImage1 = new ImageIcon("Images/Buttons/PlayButt1.png").getImage().getScaledInstance(100,50,Image.SCALE_DEFAULT);
    Image PlayButtonImage2 = new ImageIcon("Images/Buttons/PlayButt2.png").getImage();
    Image HTPButtonImage1 = new ImageIcon("Images/Buttons/HTPButt.png").getImage();
    Image HTPButtonImage2 = new ImageIcon("Images/Buttons/HTPButts.png").getImage();
    Image ExitButtonImage1 = new ImageIcon("Images/Buttons/ExitButt.png").getImage().getScaledInstance(80,32,Image.SCALE_DEFAULT);
    Image ExitButtonImage2 = new ImageIcon("Images/Buttons/ExitButts.png").getImage();
    ImageIcon BgTitelIcon = new ImageIcon("Images/MainMenu/bgtitle.png");
    ImageIcon BgIndcIcon = new ImageIcon(BgIndcImg);
    ImageIcon PlayButtonIcon1 = new ImageIcon(PlayButtonImage1);
    ImageIcon PlayButtonIcon2 = new ImageIcon(PlayButtonImage2);
    ImageIcon HTPButtonIcon1 = new ImageIcon(HTPButtonImage1);
    ImageIcon HTPButtonIcon2 = new ImageIcon(HTPButtonImage2);
    ImageIcon ExitButtonIcon1 = new ImageIcon(ExitButtonImage1);
    ImageIcon ExitButtonIcon2 = new ImageIcon(ExitButtonImage2);

    // How to Play
    Image WButtImg = new ImageIcon("Images/Buttons/WButt.gif").getImage().getScaledInstance(96,96,Image.SCALE_DEFAULT);
    Image AButtImg = new ImageIcon("Images/Buttons/AButt.gif").getImage().getScaledInstance(96,96,Image.SCALE_DEFAULT);
    Image DButtImg = new ImageIcon("Images/Buttons/DButt.gif").getImage().getScaledInstance(96,96,Image.SCALE_DEFAULT);
    Image SButtImg = new ImageIcon("Images/Buttons/SButt.gif").getImage().getScaledInstance(96,96,Image.SCALE_DEFAULT);
    Image SpaceButtImg = new ImageIcon("Images/Buttons/spaceButt.gif").getImage().getScaledInstance(240,64,Image.SCALE_DEFAULT);
    ImageIcon titleAppear = new ImageIcon("Images/Buttons/titleappear.gif");
    ImageIcon ReadyButtonIcon = new ImageIcon("Images/Buttons/readButt1.png");
    ImageIcon ReadButtonHoverIcon = new ImageIcon("Images/Buttons/readButt2.png");

    ImageIcon WButt = new ImageIcon(WButtImg);
    ImageIcon AButt = new ImageIcon(AButtImg);
    ImageIcon DButt = new ImageIcon(DButtImg);
    ImageIcon SButt = new ImageIcon(SButtImg);
    ImageIcon SpaceButt = new ImageIcon(SpaceButtImg);

    JButton HowToPlay;
    // HTTP
    JButton ReadyButton = new JButton();
    JLabel WKey = new JLabel();
    JLabel AKey = new JLabel();
    JLabel DKey = new JLabel();
    JLabel SKey = new JLabel();
    JLabel SpaceKey = new JLabel();
    JLabel title = new JLabel();

    JButton Exit;

    String Sfx = "Sounds/start.wav";

    public MainMenu() {
        MainMenu = new JPanel();
        HTTPanel = new JPanel();
        MainMenuBG = new JLabel();
        MainMenuTitle = new JLabel();
        MainMeneIndc = new JLabel();
        // MainMenu

        MainMenuBG.setHorizontalAlignment(JLabel.CENTER);
        MainMenuBG.setVerticalAlignment(JLabel.CENTER);

        Play = new JButton();
        Play.setHorizontalAlignment(JLabel.CENTER);
        Play.setVerticalAlignment(JLabel.CENTER);
        HowToPlay = new JButton();
        Exit = new JButton();

        MainMenu.setBounds(0,0,1280,720);
        MainMenu.setLayout(null);
        MainMenu.setOpaque(false);

        MainMenuTitle.setBounds(550,150,300,100);
        MainMenuTitle.setIcon(BgTitelIcon);

        MainMeneIndc.setBounds(50,300,68,54);
        MainMeneIndc.setIcon(BgIndcIcon);

        HTTPanel.setBounds(0,0,1280,720);
        HTTPanel.setLayout(null);
        HTTPanel.setOpaque(false);
        HTTPanel.setVisible(false);

        ReadyButton.setBounds(550,600,200,50);
        ReadyButton.setIcon(ReadyButtonIcon);
        ReadyButton.setOpaque(false);
        ReadyButton.setContentAreaFilled(false);
        ReadyButton.setBorderPainted(false);
        ReadyButton.setBorder(null);

        WKey.setBounds(374,350,96,96);
        WKey.setIcon(WButt);

        AKey.setBounds(312,410,96,96);
        AKey.setIcon(AButt);

        DKey.setBounds(435,410,96,96);
        DKey.setIcon(DButt);

        SKey.setBounds(374,410,96,96);
        SKey.setIcon(SButt);

        SpaceKey.setBounds(750,410,300,96);
        SpaceKey.setIcon(SpaceButt);

        HTTPanel.add(WKey);
        HTTPanel.add(AKey);
        HTTPanel.add(DKey);
        HTTPanel.add(SKey);
        HTTPanel.add(SpaceKey);
        HTTPanel.add(title);

        Play.setBounds(595,300,160,64);
        Play.setIcon(PlayButtonIcon1);
        Play.setHorizontalAlignment(JLabel.CENTER);
        Play.setVerticalAlignment(JLabel.CENTER);
        Play.setOpaque(false);
        Play.setContentAreaFilled(false);
        Play.setBorderPainted(false);
        Play.setBorder(null);
        Play.setBackground(Color.GRAY);

        HowToPlay.setBounds(580,400,195,49);
        HowToPlay.setIcon(HTPButtonIcon1);
        HowToPlay.setOpaque(false);
        HowToPlay.setContentAreaFilled(false);
        HowToPlay.setBorderPainted(false);
        HowToPlay.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        Exit.setBounds(630,460,95,32);
        Exit.setIcon(ExitButtonIcon1);
        Exit.setOpaque(false);
        Exit.setContentAreaFilled(false);
        Exit.setBorderPainted(false);
        Exit.setBorder(BorderFactory.createLineBorder(Color.BLACK));


        Play.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                Play.setIcon(new ImageIcon(PlayButtonImage2));
                Play.setCursor(new Cursor(Cursor.HAND_CURSOR));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                Play.setIcon(new ImageIcon(PlayButtonImage1));
                Play.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            }
        });
        HowToPlay.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                HowToPlay.setCursor(new Cursor(Cursor.HAND_CURSOR));
                HowToPlay.setIcon(new ImageIcon(HTPButtonImage2));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                HowToPlay.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                HowToPlay.setIcon(new ImageIcon(HTPButtonImage1));
            }
        });
        Exit.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                Exit.setCursor(new Cursor(Cursor.HAND_CURSOR));
                Exit.setIcon(ExitButtonIcon2);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                Exit.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                Exit.setIcon(ExitButtonIcon1);
            }
        });
        HowToPlay.addActionListener(e -> {
            HTTP();
        });
        Play.addActionListener(e -> {
            MainMenu.setVisible(false);
        });
        MainMenu.add(Play);
        MainMenu.add(HowToPlay);
        MainMenu.add(Exit);
        MainMenu.add(MainMenuTitle);

        MainMenu.setVisible(true);
    }

    public void HTTP() {
        HTTPanel.setVisible(true);
        MainMenu.setVisible(false);
    }

    public static void PlayMusic(String filepath) {
        // if key is pressed
        try {
            File musicFile = new File(filepath);

            if (musicFile.exists()) {
                AudioInputStream audioInput = AudioSystem.getAudioInputStream(musicFile);
                Clip clip = AudioSystem.getClip();
                clip.open(audioInput);
                FloatControl gainControl = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
                gainControl.setValue(-7.0f);
                clip.start();
            }
            else {
                System.out.println("File not found");
            }
        }
        catch (Exception e) {
            System.out.println(e);
        }
    }
}
